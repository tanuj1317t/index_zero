import ReactMarkdown from "react-markdown";
import { Sparkles, User } from "lucide-react";
import { cn } from "@/lib/utils";
import { ConfidenceBadge, extractConfidence } from "./ConfidenceBadge";

export type Msg = { role: "user" | "assistant"; content: string };

export function ChatMessage({ msg }: { msg: Msg }) {
  const isUser = msg.role === "user";
  const confidence = !isUser ? extractConfidence(msg.content) : null;

  return (
    <div className={cn("flex w-full gap-3", isUser ? "justify-end" : "justify-start")}>
      {!isUser && (
        <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[var(--gradient-primary)] text-primary-foreground shadow-[var(--shadow-glow)]">
          <Sparkles className="h-4 w-4" />
        </div>
      )}
      <div
        className={cn(
          "max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed",
          isUser
            ? "bg-primary text-primary-foreground rounded-br-sm"
            : "bg-card text-card-foreground border border-border rounded-bl-sm shadow-[var(--shadow-card)]",
        )}
      >
        {isUser ? (
          <p className="whitespace-pre-wrap">{msg.content}</p>
        ) : (
          <div className="advisor-markdown space-y-2">
            <ReactMarkdown>{msg.content || "…"}</ReactMarkdown>
            {confidence && (
              <div className="mt-3">
                <ConfidenceBadge level={confidence} />
              </div>
            )}
          </div>
        )}
      </div>
      {isUser && (
        <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-secondary text-secondary-foreground">
          <User className="h-4 w-4" />
        </div>
      )}
    </div>
  );
}
