import { cn } from "@/lib/utils";

type Level = "High" | "Medium" | "Low" | null;

export function extractConfidence(text: string): Level {
  const m = text.match(/confidence[:\s]*\**\s*(high|medium|low)/i);
  if (!m) return null;
  const v = m[1].toLowerCase();
  return (v.charAt(0).toUpperCase() + v.slice(1)) as Level;
}

export function ConfidenceBadge({ level }: { level: Level }) {
  if (!level) return null;
  const styles: Record<NonNullable<Level>, string> = {
    High: "bg-success/15 text-success border-success/30",
    Medium: "bg-warning/15 text-warning border-warning/30",
    Low: "bg-destructive/15 text-destructive border-destructive/30",
  };
  const dots = level === "High" ? 3 : level === "Medium" ? 2 : 1;
  return (
    <div
      className={cn(
        "inline-flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-medium",
        styles[level],
      )}
    >
      <span className="flex gap-0.5">
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            className={cn(
              "h-1.5 w-1.5 rounded-full",
              i < dots ? "bg-current" : "bg-current/25",
            )}
          />
        ))}
      </span>
      Confidence: {level}
    </div>
  );
}
