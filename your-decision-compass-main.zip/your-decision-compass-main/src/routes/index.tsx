import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Sparkles, Send, Loader2, RotateCcw } from "lucide-react";
import { askAdvisor } from "@/utils/advisor.functions";
import { ChatMessage, type Msg } from "@/components/advisor/ChatMessage";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Decision Advisor — Unbiased AI for Personalized Decisions" },
      {
        name: "description",
        content:
          "Decision Advisor is an unbiased AI assistant that helps you make personalized decisions by cutting through fake reviews and biased opinions.",
      },
      { property: "og:title", content: "Decision Advisor" },
      { property: "og:description", content: "Make informed, personalized decisions with an unbiased AI." },
    ],
  }),
  component: Index,
});

const SUGGESTIONS = [
  "Best laptop for programming under $1500",
  "Should I switch careers to data science?",
  "Recommend a skincare routine for oily skin",
  "Which EV should I buy in 2026?",
  "Best noise-cancelling headphones",
];

function Index() {
  const ask = useServerFn(askAdvisor);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  const send = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || loading) return;
    const next: Msg[] = [...messages, { role: "user", content: trimmed }];
    setMessages(next);
    setInput("");
    setLoading(true);
    try {
      const res = await ask({ data: { messages: next } });
      if (res.error) {
        toast.error(res.error);
      } else {
        setMessages((m) => [...m, { role: "assistant", content: res.content }]);
      }
    } catch (e) {
      console.error(e);
      toast.error("Failed to reach the advisor. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const reset = () => {
    setMessages([]);
    setInput("");
  };

  const empty = messages.length === 0;

  return (
    <div
      className="min-h-screen text-foreground"
      style={{ background: "var(--gradient-bg)" }}
    >
      <Toaster />
      {/* Header */}
      <header className="sticky top-0 z-10 backdrop-blur-xl bg-background/60 border-b border-border">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <div
              className="flex h-9 w-9 items-center justify-center rounded-xl text-primary-foreground"
              style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-glow)" }}
            >
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-base font-semibold leading-tight">Decision Advisor</h1>
              <p className="text-xs text-muted-foreground leading-tight">Unbiased AI for personal decisions</p>
            </div>
          </div>
          {!empty && (
            <Button variant="ghost" size="sm" onClick={reset} className="text-muted-foreground">
              <RotateCcw className="h-4 w-4 mr-1.5" /> New chat
            </Button>
          )}
        </div>
      </header>

      {/* Chat */}
      <main
        ref={scrollRef}
        className="mx-auto max-w-3xl px-4 pb-40 pt-6 h-[calc(100vh-64px)] overflow-y-auto"
      >
        {empty ? (
          <div className="flex flex-col items-center justify-center text-center pt-16">
            <div
              className="mb-6 flex h-16 w-16 items-center justify-center rounded-2xl text-primary-foreground"
              style={{ background: "var(--gradient-primary)", boxShadow: "var(--shadow-glow)" }}
            >
              <Sparkles className="h-8 w-8" />
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">
              What decision can I help you make?
            </h2>
            <p className="mt-3 max-w-md text-muted-foreground">
              I'll ask a few smart questions, cut through the noise, and give you a recommendation that actually fits you.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-2 max-w-xl">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => send(s)}
                  className="rounded-full border border-border bg-card/60 px-4 py-2 text-sm text-foreground/90 hover:border-primary/50 hover:bg-card transition-colors"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((m, i) => (
              <ChatMessage key={i} msg={m} />
            ))}
            {loading && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground pl-11">
                <Loader2 className="h-4 w-4 animate-spin" />
                Thinking carefully…
              </div>
            )}
          </div>
        )}
      </main>

      {/* Composer */}
      <div className="fixed bottom-0 left-0 right-0 border-t border-border bg-background/80 backdrop-blur-xl">
        <div className="mx-auto max-w-3xl px-4 py-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              send(input);
            }}
            className="flex items-end gap-2 rounded-2xl border border-border bg-card p-2 shadow-[var(--shadow-card)] focus-within:border-primary/60 transition-colors"
          >
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send(input);
                }
              }}
              placeholder="What decision can I help you make?"
              rows={1}
              className="flex-1 resize-none bg-transparent px-3 py-2 text-sm outline-none placeholder:text-muted-foreground max-h-40"
            />
            <Button
              type="submit"
              size="icon"
              disabled={loading || !input.trim()}
              className="h-10 w-10 rounded-xl"
              style={{ background: "var(--gradient-primary)", color: "var(--primary-foreground)" }}
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
            </Button>
          </form>
          <p className="mt-2 text-center text-[11px] text-muted-foreground">
            Decision Advisor synthesizes aggregated opinions. Always use your own judgment.
          </p>
        </div>
      </div>
    </div>
  );
}
