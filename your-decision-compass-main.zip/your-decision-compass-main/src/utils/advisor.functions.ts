import { createServerFn } from "@tanstack/react-start";

type ChatMessage = { role: "user" | "assistant"; content: string };

const SYSTEM_PROMPT = `You are Decision Advisor — a neutral, unbiased AI that helps users make personalized decisions.

CORE RULES:
1. PERSONALIZATION FIRST: When a user asks for a recommendation, do NOT recommend immediately. Ask 1–2 smart follow-up questions to understand their decision, budget, priorities, and constraints.
2. Once you have enough context, simulate analysis of aggregated user opinions/reviews. Focus on consistent patterns. Ignore extreme/promotional opinions.
3. Be concise, human, and trustworthy. No hype. No fluff.
4. Be honest if data is limited.

OUTPUT FORMAT:
- For initial / clarifying turns: just write a short friendly intro and the 1–2 questions. Do NOT use the section headers yet.
- Once you have enough context to recommend, ALWAYS use this exact markdown structure:

🔍 **Understanding Your Needs**
(1–2 line summary of what they want)

📊 **What People Are Saying**
- ✅ Common positives: ...
- ⚠️ Common negatives: ...

✅ **My Recommendation For You**
1. **Option 1** — (Best Fit)
2. **Option 2**
3. **Option 3**

💡 **Why This Fits You**
(personalized explanation, 2–3 sentences)

⚠️ **Things to Consider**
(short list of trade-offs)

**Confidence:** High | Medium | Low

Keep total response under ~250 words. Use plain language.`;

export const askAdvisor = createServerFn({ method: "POST" })
  .inputValidator((input: { messages: ChatMessage[] }) => input)
  .handler(async ({ data }) => {
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) {
      return { error: "AI is not configured. Missing LOVABLE_API_KEY." as const, content: "" };
    }

    try {
      const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-3-flash-preview",
          messages: [
            { role: "system", content: SYSTEM_PROMPT },
            ...data.messages,
          ],
        }),
      });

      if (res.status === 429) {
        return { error: "Rate limit reached. Please try again in a moment." as const, content: "" };
      }
      if (res.status === 402) {
        return { error: "AI credits exhausted. Please add funds in workspace settings." as const, content: "" };
      }
      if (!res.ok) {
        const txt = await res.text();
        console.error("AI gateway error", res.status, txt);
        return { error: "AI service unavailable." as const, content: "" };
      }

      const json = await res.json();
      const content: string = json?.choices?.[0]?.message?.content ?? "";
      return { error: null, content };
    } catch (e) {
      console.error("askAdvisor failed", e);
      return { error: "Something went wrong calling the AI." as const, content: "" };
    }
  });
